<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rt extends Model
{
    protected $table= "rts";
    protected $fillable= [
        'no_rt',
        'nama_rt',
        'masa_jabatan',
        'no_telp',
        'email'
    ];
    protected $PrimaryKey= "id";
}
