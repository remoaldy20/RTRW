<?php

namespace App\Http\Controllers;

use App\Alamat;
use Illuminate\Http\Request;

class AlamatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Alamat::all();
        return view('alamat.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('alamat.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data=[
            'no_rumah'=>$request->no_rumah,
            'alamat'=>$request->alamat,
        ];
        Alamat::create($data);
        return redirect('/alamat');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Alamat  $alamat
     * @return \Illuminate\Http\Response
     */
    public function show(Alamat $alamat)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Alamat  $alamat
     * @return \Illuminate\Http\Response
     */
    public function edit(Alamat $id)
    {
        $edit = Alamat::find($id);
        return view('alamat.edit', compact('edit')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Alamat  $alamat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $edit = Alamat::find($id);
        $data= [
            'no_rumah'=>$request->no_rumah,
            'alamat'=>$request->alamat
        ];
        $edit->update($data);
        return redirect('/alamat');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Alamat  $alamat
     * @return \Illuminate\Http\Response
     */
    public function destroy(Alamat $alamat)
    {
        //
    }
}
