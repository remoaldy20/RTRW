<?php

namespace App\Http\Controllers;

use App\Rw;
use Illuminate\Http\Request;

class RwController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Rw::all();
        return view('rw.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('rw.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $data=[
            'nama_rw'=>$request->nama_rw,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email,
        ];
        Rw::create($data);
        return redirect('/rw');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Rw  $rw
     * @return \Illuminate\Http\Response
     */
    public function show(Rw $rw)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Rw  $rw
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = Rw::find($id);
        return view('rw.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Rw  $rw
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $edit = Rw::find($id);
        $data=[
            'nama_rw'=>$request->nama_rw,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email,
        ];
        $edit->update($data);
        return redirect('/rw');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Rw  $rw
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $destroy = Rw::destroy($id);
        return redirect('/rw');
    }
}
