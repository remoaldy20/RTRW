<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/login', 'AuthController@login')->name('login');
Route::post('/postlogin', 'AuthController@postlogin');
Route::get('/logout', 'AuthController@logout');

Route::group(['middleware' => 'auth'],function(){
Route::get('/', function () {
    return view('layouts.app');
});
//warga
Route::get('/warga','WargaController@index');
Route::get('/warga/create','WargaController@create');
Route::post('/warga/store','WargaController@store');
Route::get('/warga/show/{id}', 'WargaController@show');
Route::get('/warga/edit/{id}','WargaController@edit');
Route::put('/warga/update/{id}','WargaController@update');
Route::get('/warga/delete/{id}','WargaController@destroy');
//rt
Route::get('/rt', 'RtController@index');
Route::get('/rt/create', 'RtController@create');
Route::post('rt/store', 'RtController@store');
Route::get('/rt/edit/{id}', 'RtController@edit');
Route::put('/rt/update/{id}', 'RtController@update');
Route::get('rt/delete/{id}', 'RtController@destroy');
//rw
Route::get('/rw', 'RwController@index');
Route::get('/rw/create', 'RwController@create');
Route::post('/rw/store', 'RwController@store');
Route::get('/rw/edit/{id}', 'RwController@edit');
Route::put('/rw/update/{id}', 'RwController@update');
Route::get('/rw/delete/{id}', 'RwController@destroy');
//kelurahan
Route::get('/kelurahan','KelurahanController@index');
Route::get('/kelurahan/create', 'KelurahanController@create');
Route::post('/kelurahan/store', 'KelurahanController@store');
Route::get('/kelurahan/edit/{id}', 'KelurahanController@edit');
Route::put('/kelurahan/update/{id}', 'KelurahanController@update');
Route::get('/kelurahan/delete/{id}', 'KelurahanController@destroy');
//kecamatan
Route::get('/kecamatan', 'KecamatanController@index');
Route::get('/kecamatan/create', 'KecamatanController@create');
Route::post('/kecamatan/store', 'KecamatanController@store');
Route::get('/kecamatan/edit/{id}', 'KecamatanController@edit');
Route::put('/kecamatan/update/{id}', 'kecamatanController@update');
Route::get('/kecamatan/delete/{id}', 'kecamatancontroller@destroy');
//iuran
Route::get('/iuran', 'IuranController@index');
Route::get('/iuran/create', 'iuranController@create');
Route::post('/iuran/store', 'IuranController@store');
Route::get('/iuran/edit/{id}', 'IuranController@edit');
Route::put('/iuran/update/{id}','IuranController@update');
Route::get('/iuran/delete/{id}', 'iuranController@destroy');
//program
Route::get('/program', 'ProgramController@index');
Route::get('/program/create', 'ProgramController@create');
Route::post('/program/store', 'ProgramController@store');
Route::get('/program/edit/{id}', 'ProgramController@edit');
Route::put('/program/update/{id}', 'ProgramController@update');
Route::get('/program/delete/{id}', 'ProgramController@destroy');
//petugas
Route::get('/petugas', 'PetugasController@index');
Route::get('/petugas/create', 'PetugasController@create');
Route::post('/petugas/store', 'PetugasController@store');
Route::get('/petugas/edit/{id}', 'PetugasController@edit');
Route::put('/petugas/update/{id}', "PetugasController@update");
Route::get('/petugas/delete/{id}', 'PetugasController@destroy');
//alamat
Route::get('/alamat', 'AlamatController@index');
Route::get('/alamat/create', 'AlamatController@create');
Route::post('/alamat/store', 'AlamatController@store');
Route::get('/alamat/edit/{id}', 'AlamatController@edit');
Route::put('/alamat/update/{id}', 'AlamatController@update');
Route::get('/alamat/delete/{id}', 'AlamatController@destroy');
});