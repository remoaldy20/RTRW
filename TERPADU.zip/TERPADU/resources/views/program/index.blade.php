@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROGRAM</title>
</head>
<body>
    <a href="/program/create" class="btn btn-secondary">Tambah</a>
     <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>Kas</td>
            <td>Kebersihan</td>
            <td>Keamanan</td>
            <td>Kematian</td>
            <td>Kegiatan</td>
            <td>Bencana</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $program)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$program->kas}}</td>
            <td>{{$program->kebersihan}}</td>
            <td>{{$program->keamanan}}</td>
            <td>{{$program->kematian}}</td>
            <td>{{$program->kegiatan}}</td>
            <td>{{$program->bencana}}</td>
            <td>
                <a href="/program/edit/{{$program->id}}" class="btn btn-warning">Edit</a>
                <a href="/program/delete/{{$program->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection