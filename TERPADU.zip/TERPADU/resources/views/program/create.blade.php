@extends('layouts.app')
@section('content')
    <form action="/program/store" method="post">
        @csrf
<div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Input Data Program</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Kas</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="kas" name="kas">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Kebersihan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="kebersihan" name="kebersihan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">Keamanan</label>
                                            <input type="text" id="country-floating" class="form-control" name="keamanan" placeholder="keamanan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="company-column">Kematian</label>
                                            <input type="date" id="company-column" class="form-control" name="kematian" placeholder="kematian">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kegiatan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kegiatan" placeholder="kegiatan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Bencana</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="bencana" name="bencana">
                                        </div>
                                    </div>
                                    <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@endsection