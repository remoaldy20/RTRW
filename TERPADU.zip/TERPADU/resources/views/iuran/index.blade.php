@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>IURAN</title>
    </head>
    <body>
        <h3>DATA IURAN</h3>
    <a href="/iuran/create" class="btn btn-secondary">Tambah</a>
     <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>Tanggal Update</td>
            <td>Nominal</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $iuran)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$iuran->tgl_update}}</td>
            <td>{{$iuran->nominal}}</td>
            <td>
                <a href="/iuran/edit/{{$iuran->id}}" class="btn btn-warning">Edit</a>
                <a href="/iuran/delete/{{$iuran->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection