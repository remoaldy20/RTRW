@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>WARGA</title>
</head>
<body>
    <h3>DATA WARGA</h3>
    <a href="/warga/create" class="btn btn-secondary">Tambah</a>
    <table class="table table-hover mb-0" >
        <tr>
            <td>No</td>
            <td>NIK</td>
            <td>Nama</td>
            <td>Jenis Kelamin</td>
            <td>Action</td>
            </tr>
        @foreach ($data as $isi => $warga)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$warga->nik}}</td>
            <td>{{$warga->nama}}</td>
            <td>{{$warga->jenkel}}</td>
            <td>
                <a href="/warga/edit/{{$warga->id}}" class="btn btn-warning">edit</a>
                <a href="/warga/show/{{$warga->id}}" class="btn btn-info">Show</a>
                <a href="/warga/delete/{{$warga->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection