@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <tr>
            <td>NIK</td>
            <td>: {{$data->nik}}</td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: {{$data->nama}}</td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: {{$data->jenkel}}</td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>: {{$data->tempat_lahir}}</td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>: {{$data->tanggal_lahir}}</td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>: {{$data->pekerjaan}}</td>
        </tr>
        <tr>
            <td>Penghasilan</td>
            <td>: {{$data->penghasilan}}</td>
        </tr>
        <tr>
            <td>Kota</td>
            <td>: {{$data->kota}}</td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: {{$data->email}}</td>
        </tr>
        <tr>
            <td>Password</td>
            <td>: {{$data->password}}</td>
        </tr>
        <tr>
            <td>QR code</td>
            <td>: {{$data->qr_code}}</td>
        </tr>
        <tr>
            <td>
                <a href="/warga" class="btn btn-secondary mr-1 mb-1">Kembali</a>
            </td>
        </tr>
    </table>
</body>
</html>
@endsection