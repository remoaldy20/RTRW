@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RT</title>
</head>
<body>
    <h3>DATA RT</h3>
    <a href="/rt/create" class="btn btn-secondary">Tambah</a>
    <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>Nama RT</td>
            <td>Masa Jabatan</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $rt)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$rt->nama_rt}}</td>
            <td>{{$rt->masa_jabatan}}</td>
            <td>{{$rt->no_telp}}</td>
            <td>{{$rt->email}}</td>
            <td>
                <a href="/rt/edit/{{$rt->id}}" class="btn btn-warning">Edit</a>
                <a href="/rt/delete/{{$rt->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection