@extends('layouts.app')
@section('content')
    <form action="/kelurahan/update/{{$edit->id}}" method="post">
        @csrf
        @method('PUT')
<div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data Kelurahan</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Nama Kelurahan</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="nama kelurahan" name="nama_kelurahan" value="{{$edit->nama_kelurahan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nama lurah</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="nama lurah" name="nama_lurah" value="{{$edit->nama_lurah}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Masa Jabatan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="masa jabatan" name="masa_jabatan" value="{{$edit->masa_jabatan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">No Telp</label>
                                            <input type="text" id="country-floating" class="form-control" name="no_telp" placeholder="no telp" value="{{$edit->no_telp}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="company-column">Email</label>
                                            <input type="email" id="company-column" class="form-control" name="email" placeholder="email" value="{{$edit->email}}">
                                        </div>
                                    </div>
                                    <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <a href="/kelurahan" class="btn btn-secondary mr-1 mb-1">Kembali</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@endsection