@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ALAMAT</title>
    </head>
    <body>
        <h3>DATA ALAMAT</h3>
    <a href="/alamat/create" class="btn btn-secondary">Tambah</a>
     <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>No Rumah</td>
            <td>Jalan</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $al)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$al->no_rumah}}</td>
            <td>{{$al->alamat}}</td>
            <td>
                <a href="/alamat/edit/{{$al->id}}" class="btn btn-warning">Edit</a>
                <a href="/alamat/delete/{{$al->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection