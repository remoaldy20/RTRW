@extends('layouts.app')
@section('content')
    <form action="/alamat/update/{{$edit->id}}" method="post">
        @csrf
        @method('PUT')
<div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data Alamat</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">No Rumah</label>
                                            <input type="number" id="first-name-column" class="form-control" placeholder="no rumah" name="no_rumah" value="{{$edit->no_rumah}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group mb-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Jalan</label>
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="alamat" placeholder="jalan" value="{{$edit->alamat}}"></textarea>
                                        </div>
                                    <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <a href="/alamat" class="btn btn-secondary mr-1 mb-1">Kembali</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@endsection