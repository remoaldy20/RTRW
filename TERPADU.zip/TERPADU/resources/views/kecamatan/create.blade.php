@extends('layouts.app')
@section('content')
    <form action="/kecamatan/store" method="post">
        @csrf
<div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Input Data Kecamatan</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Nama Kecamatan</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="nama kecamatan" name="nama_kecamatan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nama Camat</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="nama camat" name="nama_camat">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Masa Jabatan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="masa jabatan" name="masa_jabatan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">No Telp</label>
                                            <input type="text" id="country-floating" class="form-control" name="no_telp" placeholder="no telp">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="company-column">Email</label>
                                            <input type="email" id="company-column" class="form-control" name="email" placeholder="email">
                                        </div>
                                    </div>
                                    <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
@endsection