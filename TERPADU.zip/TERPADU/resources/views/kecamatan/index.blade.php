@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kecamatan</title>
</head>
<body>
    <h3>DATA KECAMATAN</h3>
    <a href="/kecamatan/create" class="btn btn-secondary">Tambah</a>
      <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>Nama Kecamatan</td>
            <td>Nama camat</td>
            <td>Masa Jabatan</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $kec)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$kec->nama_kecamatan}}</td>
            <td>{{$kec->nama_camat}}</td>
            <td>{{$kec->masa_jabatan}}</td>
            <td>{{$kec->no_telp}}</td>
            <td>{{$kec->email}}</td>
           <td>
                <a href="/kecamatan/edit/{{$kec->id}}" class="btn btn-warning">Edit</a>
                <a href="/kecamatan/delete/{{$kec->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection