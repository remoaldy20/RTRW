@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PETUGAS</title>
</head>
<body>
    <h3>DATA PETUGAS</h3>
    <a href="/petugas/create" class="btn btn-secondary">Tambah</a>
     <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>Nama Petugas</td>
            <td>Email</td>
            <td>Password</td>
            <td>No Telp</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $pet)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$pet->nama_petugas}}</td>
            <td>{{$pet->email}}</td>
            <td>{{$pet->password}}</td>
            <td>{{$pet->no_telp}}</td>
            <td>
                <a href="/petugas/edit/{{$pet->id}}" class="btn btn-warning">Edit</a>
                <a href="/petugas/delete/{{$pet->id}}" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>
@endsection