<?php $__env->startSection('content'); ?>
     <form action="/rt/update/<?php echo e($edit->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
<div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data RT</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Nama RT</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="nama rt" name="nama_rt" value="<?php echo e($edit->nama_rt); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">Masa Jabatan</label>
                                            <input type="text" id="country-floating" class="form-control" name="masa_jabatan" placeholder="masa jabatan" value="<?php echo e($edit->masa_jabatan); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="company-column">No Telp</label>
                                            <input type="text" id="company-column" class="form-control" name="no_telp" placeholder="no telp" value="<?php echo e($edit->no_telp); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Email</label>
                                            <input type="email" id="email-id-column" class="form-control" name="email" placeholder="email" value="<?php echo e($edit->email); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <a href="/rt" class="btn btn-secondary mr-1 mb-1">Kembali</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/rt/edit.blade.php ENDPATH**/ ?>