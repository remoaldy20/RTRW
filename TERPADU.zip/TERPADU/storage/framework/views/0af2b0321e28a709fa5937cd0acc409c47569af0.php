        <ul class="menu">
            
            
                <li class='sidebar-title'>Main Menu</li>
            
            
            
                <li class="sidebar-item active ">
                    <a href="/dashboard" class='sidebar-link'>
                        <i data-feather="home" width="20"></i> 
                        <span>Dashboard</span>
                    </a>
                    
                </li>
            
            
            
                <li class='sidebar-title'>Forms &amp; Tables</li>
            
            
            
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i data-feather="file-text" width="20"></i> 
                        <span>Data - Data Wilayah</span>
                    </a>
                    
                    <ul class="submenu ">

                        <li>
                            <a href="/alamat">AlAMAT</a>
                        </li>
                        
                        <li>
                            <a href="/rt">RT</a>
                        </li>
                        
                        <li>
                            <a href="/rw">RW</a>
                        </li>
                        
                        <li>
                            <a href="/kecamatan">Kecamatan</a>
                        </li>
                        
                        <li>
                            <a href="/kelurahan">Kelurahan</a>
                        </li>
                        
                        <li>
                            <a href="/iuran">Iuran</a>
                        </li>
                        
                    </ul>
                    
                </li>

            
            
            
                <li class="sidebar-item  ">
                    <a href="/warga" class='sidebar-link'>
                        <i data-feather="layout" width="20"></i> 
                        <span>Data Warga</span>
                    </a>
                    
                </li>

            
                <li class="sidebar-item  ">
                    <a href="/petugas" class='sidebar-link'>
                        <i data-feather="layers" width="20"></i> 
                        <span>Data Petugas</span>
                    </a>
                    
                </li>

        
                <li class="sidebar-item  ">
                    <a href="/program" class='sidebar-link'>
                        <i data-feather="grid" width="20"></i> 
                        <span>Data Program</span>
                    </a>
                    
                </li>
            
            
         
        </ul><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>