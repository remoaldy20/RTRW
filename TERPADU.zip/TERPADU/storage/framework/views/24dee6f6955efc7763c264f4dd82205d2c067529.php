<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>WARGA</title>
</head>
<body>
    <h3>DATA WARGA</h3>
    <a href="/warga/create" class="btn btn-secondary">Tambah</a>
    <table class="table table-hover mb-0" >
        <tr>
            <td>No</td>
            <td>NIK</td>
            <td>Nama</td>
            <td>Jenis Kelamin</td>
            <td>Action</td>
            </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $warga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($warga->nik); ?></td>
            <td><?php echo e($warga->nama); ?></td>
            <td><?php echo e($warga->jenkel); ?></td>
            <td>
                <a href="/warga/edit/<?php echo e($warga->id); ?>" class="btn btn-warning">edit</a>
                <a href="/warga/show/<?php echo e($warga->id); ?>" class="btn btn-info">Show</a>
                <a href="/warga/delete/<?php echo e($warga->id); ?>" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/warga/index.blade.php ENDPATH**/ ?>