<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RT</title>
</head>
<body>
    <h3>DATA RT</h3>
    <a href="/rt/create" class="btn btn-secondary">Tambah</a>
    <table class="table table-hover mb-0">
        <tr>
            <td>No</td>
            <td>Nama RT</td>
            <td>Masa Jabatan</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($rt->nama_rt); ?></td>
            <td><?php echo e($rt->masa_jabatan); ?></td>
            <td><?php echo e($rt->no_telp); ?></td>
            <td><?php echo e($rt->email); ?></td>
            <td>
                <a href="/rt/edit/<?php echo e($rt->id); ?>" class="btn btn-warning">Edit</a>
                <a href="/rt/delete/<?php echo e($rt->id); ?>" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/rt/index.blade.php ENDPATH**/ ?>