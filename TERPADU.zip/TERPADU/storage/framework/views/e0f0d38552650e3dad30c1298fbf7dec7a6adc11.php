<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <tr>
            <td>NIK</td>
            <td>: <?php echo e($data->nik); ?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: <?php echo e($data->nama); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>: <?php echo e($data->jenkel); ?></td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>: <?php echo e($data->tempat_lahir); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>: <?php echo e($data->tanggal_lahir); ?></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>: <?php echo e($data->pekerjaan); ?></td>
        </tr>
        <tr>
            <td>Penghasilan</td>
            <td>: <?php echo e($data->penghasilan); ?></td>
        </tr>
        <tr>
            <td>Kota</td>
            <td>: <?php echo e($data->kota); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: <?php echo e($data->email); ?></td>
        </tr>
        <tr>
            <td>Password</td>
            <td>: <?php echo e($data->password); ?></td>
        </tr>
        <tr>
            <td>QR code</td>
            <td>: <?php echo e($data->qr_code); ?></td>
        </tr>
        <tr>
            <td>
                <a href="/warga" class="btn btn-secondary mr-1 mb-1">Kembali</a>
            </td>
        </tr>
    </table>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/warga/show.blade.php ENDPATH**/ ?>